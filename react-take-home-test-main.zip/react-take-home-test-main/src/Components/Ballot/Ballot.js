import React from 'react';

const Ballot = () => {
  return (
    <div className='ballot'>
      'Your Code Goes Here'
    </div>
  )
}

export default Ballot;